// Generated from: features\07-user-logs.feature
import { test } from "../../features/steps/fixtures.js";

test.describe('7. User Logs', () => {

  test.beforeEach('Background', async ({ Given, And, page }, testInfo) => { if (testInfo.error) return;
    await Given('I am logged in as RBAC admin', null, { page }); 
    await And('I open the "User Logs" module', null, { page }); 
  });
  
  test('User logs grid loads with expected columns', async ({ Then, And, ctx, page }) => { 
    await Then('I should see "RBAC User Transactions"', null, { ctx, page }); 
    await And('the grid should have the columns:', {"dataTable":{"rows":[{"cells":[{"value":"transaction Id"}]},{"cells":[{"value":"activity Start Date"}]},{"cells":[{"value":"activity End Date"}]},{"cells":[{"value":"Screen"}]},{"cells":[{"value":"user Activity"}]},{"cells":[{"value":"modified By"}]}]}}, { page }); 
    await And('I capture a screenshot "user logs grid"', null, { page }); 
  });

  test('User logs record the role assignment', async ({ When, Then, And, ctx, page }) => { 
    await When('I search for "$ROLE"', null, { ctx, page }); 
    await Then('the first row should contain "$ROLE"', null, { ctx, page }); 
    await And('every visible row should contain "$ROLE"', null, { ctx, page }); 
    await And('I should see "assigned"', null, { ctx, page }); 
    await And('I capture a screenshot "assignment in user logs"', null, { page }); 
  });

  test('User logs record the changes made to the test user', async ({ When, Then, And, ctx, page }) => { 
    await When('I search for "$USER"', null, { ctx, page }); 
    await Then('the first row should contain "$USER"', null, { ctx, page }); 
    await And('every visible row should contain "$USER"', null, { ctx, page }); 
    await And('I capture a screenshot "test user changes in user logs"', null, { page }); 
  });

  test('Search user logs filters by activity', async ({ When, Then, And, ctx, page }) => { 
    await When('I search for "role is created"', null, { ctx, page }); 
    await Then('every visible row should contain "role is created"', null, { ctx, page }); 
    await And('I capture a screenshot "user logs filtered"', null, { page }); 
  });

  test('Search user logs with no match shows empty state', async ({ When, Then, And, ctx, page }) => { 
    await When('I search for "zzz_no_such_log_999"', null, { ctx, page }); 
    await Then('the grid should show no matching records', null, { page }); 
    await And('I capture a screenshot "user logs no match"', null, { page }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('features\\07-user-logs.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":11,"pickleLine":10,"tags":[],"steps":[{"pwStepLine":7,"gherkinStepLine":7,"keywordType":"Context","textWithKeyword":"Given I am logged in as RBAC admin","isBg":true,"stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":8,"keywordType":"Context","textWithKeyword":"And I open the \"User Logs\" module","isBg":true,"stepMatchArguments":[{"group":{"start":11,"value":"\"User Logs\"","children":[{"start":12,"value":"User Logs","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":12,"gherkinStepLine":11,"keywordType":"Outcome","textWithKeyword":"Then I should see \"RBAC User Transactions\"","stepMatchArguments":[{"group":{"start":13,"value":"\"RBAC User Transactions\"","children":[{"start":14,"value":"RBAC User Transactions","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":13,"gherkinStepLine":12,"keywordType":"Outcome","textWithKeyword":"And the grid should have the columns:","stepMatchArguments":[]},{"pwStepLine":14,"gherkinStepLine":19,"keywordType":"Outcome","textWithKeyword":"And I capture a screenshot \"user logs grid\"","stepMatchArguments":[{"group":{"start":23,"value":"\"user logs grid\"","children":[{"start":24,"value":"user logs grid","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":17,"pickleLine":21,"tags":[],"steps":[{"pwStepLine":7,"gherkinStepLine":7,"keywordType":"Context","textWithKeyword":"Given I am logged in as RBAC admin","isBg":true,"stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":8,"keywordType":"Context","textWithKeyword":"And I open the \"User Logs\" module","isBg":true,"stepMatchArguments":[{"group":{"start":11,"value":"\"User Logs\"","children":[{"start":12,"value":"User Logs","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":18,"gherkinStepLine":22,"keywordType":"Action","textWithKeyword":"When I search for \"$ROLE\"","stepMatchArguments":[{"group":{"start":13,"value":"\"$ROLE\"","children":[{"start":14,"value":"$ROLE","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":19,"gherkinStepLine":23,"keywordType":"Outcome","textWithKeyword":"Then the first row should contain \"$ROLE\"","stepMatchArguments":[{"group":{"start":29,"value":"\"$ROLE\"","children":[{"start":30,"value":"$ROLE","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":20,"gherkinStepLine":24,"keywordType":"Outcome","textWithKeyword":"And every visible row should contain \"$ROLE\"","stepMatchArguments":[{"group":{"start":33,"value":"\"$ROLE\"","children":[{"start":34,"value":"$ROLE","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":21,"gherkinStepLine":25,"keywordType":"Outcome","textWithKeyword":"And I should see \"assigned\"","stepMatchArguments":[{"group":{"start":13,"value":"\"assigned\"","children":[{"start":14,"value":"assigned","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":22,"gherkinStepLine":26,"keywordType":"Outcome","textWithKeyword":"And I capture a screenshot \"assignment in user logs\"","stepMatchArguments":[{"group":{"start":23,"value":"\"assignment in user logs\"","children":[{"start":24,"value":"assignment in user logs","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":25,"pickleLine":28,"tags":[],"steps":[{"pwStepLine":7,"gherkinStepLine":7,"keywordType":"Context","textWithKeyword":"Given I am logged in as RBAC admin","isBg":true,"stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":8,"keywordType":"Context","textWithKeyword":"And I open the \"User Logs\" module","isBg":true,"stepMatchArguments":[{"group":{"start":11,"value":"\"User Logs\"","children":[{"start":12,"value":"User Logs","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":26,"gherkinStepLine":29,"keywordType":"Action","textWithKeyword":"When I search for \"$USER\"","stepMatchArguments":[{"group":{"start":13,"value":"\"$USER\"","children":[{"start":14,"value":"$USER","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":27,"gherkinStepLine":30,"keywordType":"Outcome","textWithKeyword":"Then the first row should contain \"$USER\"","stepMatchArguments":[{"group":{"start":29,"value":"\"$USER\"","children":[{"start":30,"value":"$USER","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":28,"gherkinStepLine":31,"keywordType":"Outcome","textWithKeyword":"And every visible row should contain \"$USER\"","stepMatchArguments":[{"group":{"start":33,"value":"\"$USER\"","children":[{"start":34,"value":"$USER","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":29,"gherkinStepLine":32,"keywordType":"Outcome","textWithKeyword":"And I capture a screenshot \"test user changes in user logs\"","stepMatchArguments":[{"group":{"start":23,"value":"\"test user changes in user logs\"","children":[{"start":24,"value":"test user changes in user logs","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":32,"pickleLine":34,"tags":[],"steps":[{"pwStepLine":7,"gherkinStepLine":7,"keywordType":"Context","textWithKeyword":"Given I am logged in as RBAC admin","isBg":true,"stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":8,"keywordType":"Context","textWithKeyword":"And I open the \"User Logs\" module","isBg":true,"stepMatchArguments":[{"group":{"start":11,"value":"\"User Logs\"","children":[{"start":12,"value":"User Logs","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":33,"gherkinStepLine":35,"keywordType":"Action","textWithKeyword":"When I search for \"role is created\"","stepMatchArguments":[{"group":{"start":13,"value":"\"role is created\"","children":[{"start":14,"value":"role is created","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":34,"gherkinStepLine":36,"keywordType":"Outcome","textWithKeyword":"Then every visible row should contain \"role is created\"","stepMatchArguments":[{"group":{"start":33,"value":"\"role is created\"","children":[{"start":34,"value":"role is created","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":35,"gherkinStepLine":37,"keywordType":"Outcome","textWithKeyword":"And I capture a screenshot \"user logs filtered\"","stepMatchArguments":[{"group":{"start":23,"value":"\"user logs filtered\"","children":[{"start":24,"value":"user logs filtered","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":38,"pickleLine":39,"tags":[],"steps":[{"pwStepLine":7,"gherkinStepLine":7,"keywordType":"Context","textWithKeyword":"Given I am logged in as RBAC admin","isBg":true,"stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":8,"keywordType":"Context","textWithKeyword":"And I open the \"User Logs\" module","isBg":true,"stepMatchArguments":[{"group":{"start":11,"value":"\"User Logs\"","children":[{"start":12,"value":"User Logs","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":39,"gherkinStepLine":40,"keywordType":"Action","textWithKeyword":"When I search for \"zzz_no_such_log_999\"","stepMatchArguments":[{"group":{"start":13,"value":"\"zzz_no_such_log_999\"","children":[{"start":14,"value":"zzz_no_such_log_999","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":40,"gherkinStepLine":41,"keywordType":"Outcome","textWithKeyword":"Then the grid should show no matching records","stepMatchArguments":[]},{"pwStepLine":41,"gherkinStepLine":42,"keywordType":"Outcome","textWithKeyword":"And I capture a screenshot \"user logs no match\"","stepMatchArguments":[{"group":{"start":23,"value":"\"user logs no match\"","children":[{"start":24,"value":"user logs no match","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
]; // bdd-data-end