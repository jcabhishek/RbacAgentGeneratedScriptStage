// Custom fixtures for the BDD (Cucumber) suite.
// `ctx` is per-scenario state shared between steps (current dialog, remembered values).
const { test: base, createBdd } = require('playwright-bdd');
const { uniqueSuffix, runNames } = require('../../tests/rbac/helpers');

// Records created by the ordered flow (02 Application -> 03 Pages -> 04 Features -> 05 Roles ->
// 06 Users). The run id is shared by every feature in the run (see playwright.config.ts);
// the "B" suffix keeps them apart from the records created by the spec suite.
const names = runNames('B');
const TOKENS = {
  $EMAIL: process.env.RBAC_EMAIL,
  $APP: names.APP,
  $PAGE: names.PAGE,
  $FEATURE: names.FEATURE,
  $ROLE: names.ROLE,
  $FEATURE2: names.FEATURE2,
  $USER: names.USER_ID,
  $USER2: names.USER2_ID,
  $EXISTING_APP: names.EXISTING_APP,
  $EMPTY_APP: names.EMPTY_APP,
};

const test = base.extend({
  ctx: async ({}, use) => {
    const ctx = {
      // Replace $TOKENS in step text. $TEMP is a fresh name, fixed for the whole scenario.
      resolve(text) {
        return text.replace(/\$[A-Z_0-9]+/g, token => {
          if (token === '$TEMP') return (ctx.temp ||= `PW_AUTO_TMP_${uniqueSuffix()}`);
          if (token === '$REMEMBERED') return ctx.remembered ?? token;
          return TOKENS[token] ?? token;
        });
      },
    };
    await use(ctx);
  },
});

module.exports = { test, TOKENS, ...createBdd(test) };
