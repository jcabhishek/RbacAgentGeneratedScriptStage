// Generated from: features\01-login.feature
import { test } from "../../features/steps/fixtures.js";

test.describe('1. Login', () => {

  test('Login with valid credentials lands on dashboard', async ({ Given, When, Then, And, ctx, page }) => { 
    await Given('I am on the login page', null, { page }); 
    await When('I log in with valid admin credentials', null, { page }); 
    await Then('I should be on the dashboard', null, { page }); 
    await And('I should see "RBAC Admin"', null, { ctx, page }); 
    await And('I capture a screenshot "dashboard"', null, { page }); 
  });

  test('Login with invalid password shows error', async ({ Given, When, Then, And, ctx, page }) => { 
    await Given('I am on the login page', null, { page }); 
    await When('I log in with email "$EMAIL" and password "WrongPass@000"', null, { ctx, page }); 
    await Then('I should see "Invalid password. please enter correct password."', null, { ctx, page }); 
    await And('I should be on the login page', null, { page }); 
    await And('I capture a screenshot "invalid password error"', null, { page }); 
  });

  test('Login with empty fields stays on login page', async ({ Given, When, Then, And, page }) => { 
    await Given('I am on the login page', null, { page }); 
    await When('I click LOGIN', null, { page }); 
    await Then('I should be on the login page', null, { page }); 
    await And('I capture a screenshot "empty login"', null, { page }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('features\\01-login.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":6,"pickleLine":6,"tags":[],"steps":[{"pwStepLine":7,"gherkinStepLine":7,"keywordType":"Context","textWithKeyword":"Given I am on the login page","stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":8,"keywordType":"Action","textWithKeyword":"When I log in with valid admin credentials","stepMatchArguments":[]},{"pwStepLine":9,"gherkinStepLine":9,"keywordType":"Outcome","textWithKeyword":"Then I should be on the dashboard","stepMatchArguments":[]},{"pwStepLine":10,"gherkinStepLine":10,"keywordType":"Outcome","textWithKeyword":"And I should see \"RBAC Admin\"","stepMatchArguments":[{"group":{"start":13,"value":"\"RBAC Admin\"","children":[{"start":14,"value":"RBAC Admin","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":11,"gherkinStepLine":11,"keywordType":"Outcome","textWithKeyword":"And I capture a screenshot \"dashboard\"","stepMatchArguments":[{"group":{"start":23,"value":"\"dashboard\"","children":[{"start":24,"value":"dashboard","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":14,"pickleLine":13,"tags":[],"steps":[{"pwStepLine":15,"gherkinStepLine":14,"keywordType":"Context","textWithKeyword":"Given I am on the login page","stepMatchArguments":[]},{"pwStepLine":16,"gherkinStepLine":15,"keywordType":"Action","textWithKeyword":"When I log in with email \"$EMAIL\" and password \"WrongPass@000\"","stepMatchArguments":[{"group":{"start":20,"value":"\"$EMAIL\"","children":[{"start":21,"value":"$EMAIL","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":42,"value":"\"WrongPass@000\"","children":[{"start":43,"value":"WrongPass@000","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":17,"gherkinStepLine":16,"keywordType":"Outcome","textWithKeyword":"Then I should see \"Invalid password. please enter correct password.\"","stepMatchArguments":[{"group":{"start":13,"value":"\"Invalid password. please enter correct password.\"","children":[{"start":14,"value":"Invalid password. please enter correct password.","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":18,"gherkinStepLine":17,"keywordType":"Outcome","textWithKeyword":"And I should be on the login page","stepMatchArguments":[]},{"pwStepLine":19,"gherkinStepLine":18,"keywordType":"Outcome","textWithKeyword":"And I capture a screenshot \"invalid password error\"","stepMatchArguments":[{"group":{"start":23,"value":"\"invalid password error\"","children":[{"start":24,"value":"invalid password error","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":22,"pickleLine":20,"tags":[],"steps":[{"pwStepLine":23,"gherkinStepLine":21,"keywordType":"Context","textWithKeyword":"Given I am on the login page","stepMatchArguments":[]},{"pwStepLine":24,"gherkinStepLine":22,"keywordType":"Action","textWithKeyword":"When I click LOGIN","stepMatchArguments":[]},{"pwStepLine":25,"gherkinStepLine":23,"keywordType":"Outcome","textWithKeyword":"Then I should be on the login page","stepMatchArguments":[]},{"pwStepLine":26,"gherkinStepLine":24,"keywordType":"Outcome","textWithKeyword":"And I capture a screenshot \"empty login\"","stepMatchArguments":[{"group":{"start":23,"value":"\"empty login\"","children":[{"start":24,"value":"empty login","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
]; // bdd-data-end