// Generated from: features\09-logout.feature
import { test } from "../../features/steps/fixtures.js";

test.describe('9. Logout', () => {

  test('Logout returns to login page', async ({ Given, When, Then, And, page }) => { 
    await Given('I am logged in as RBAC admin', null, { page }); 
    await When('I log out', null, { page }); 
    await Then('I should be on the login page', null, { page }); 
    await And('I capture a screenshot "logged out"', null, { page }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('features\\09-logout.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":6,"pickleLine":6,"tags":[],"steps":[{"pwStepLine":7,"gherkinStepLine":7,"keywordType":"Context","textWithKeyword":"Given I am logged in as RBAC admin","stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":8,"keywordType":"Action","textWithKeyword":"When I log out","stepMatchArguments":[]},{"pwStepLine":9,"gherkinStepLine":9,"keywordType":"Outcome","textWithKeyword":"Then I should be on the login page","stepMatchArguments":[]},{"pwStepLine":10,"gherkinStepLine":10,"keywordType":"Outcome","textWithKeyword":"And I capture a screenshot \"logged out\"","stepMatchArguments":[{"group":{"start":23,"value":"\"logged out\"","children":[{"start":24,"value":"logged out","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
]; // bdd-data-end